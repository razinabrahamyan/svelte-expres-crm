import * as universal from "../../../../src/routes/+layout.js";
export { universal };
export { default as component } from "../../../../src/routes/+layout.svelte";